<?php
/*$email_to = 'Reservation@imusixplace.co.uk';
if(isset($_POST['submit'])){ 
                                     
                                        
									 $name = $_POST['Name'];
									 $email = $_POST['Email']; 
									 $message = $_POST['Message'];
									  
 $subject = "Client Details";

// $message = 'Dear '.$_POST['name'].',<br>';
$message = "
name: $name <br><br>
email: $email <br><br>  
message: $message <br><br>

";
// $message .= "Regards,<br>";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <'.$email .'>'. "\r\n";
$headers .= 'Cc: mbilalhussain38@gmail.com' . "\r\n";

$mailto = mail($email_to,$subject,$message,$headers);
if($mailto){
 $Messages ='<div class="alert alert-success alert-dismissible fade show" role="alert">
 <strong>Thank You!</strong> We Received Your Email.
 <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
}
}